const {
    smd,
    prefix, 
    Config ,
    sleep
     } = require('../lib')







smd({
    cmdname: "hack",    
    type: "fun",    
    info: "hacking prank",    
    filename: __filename,

},

async(citel) => {    
await citel.send("Injecting Malware")   
await sleep(2000)    
await citel.send(" █ 10%")    
await sleep(1000)    
await citel.send(" █ █ 20%")    
await sleep(1000)    
await citel.send(" █ █ █ 30%")    
await sleep(1000)    
await citel.send(" █ █ █ █ 40%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ 50%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ 60%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ 70%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ █ 80%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ █ █ 90%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ █ █ █ 100%")    
await sleep(1000)    
await citel.send("System hyjacking on process.. \n Conecting to Server error to find 404 ")    
await sleep(1000)    
await citel.send("Device successfully connected... \n Riciving data...")    
await sleep(1000)    
await citel.send("Data hyjacked from divice 100% completed \n killing all evidence killing all malwares...")
await sleep(1000)    
await citel.send(" HACKING COMPLETED HESHAN MD ")    
await sleep(2000)    
await citel.send(" SENDING LOG DOCUMENTS...")    
await sleep(1000)
await citel.send(" SUCCESSFULLY SENT DATA AND Connection disconnected")    
await sleep(1000)

    return await citel.send('BACKLOGS CLEARED');

}

)
